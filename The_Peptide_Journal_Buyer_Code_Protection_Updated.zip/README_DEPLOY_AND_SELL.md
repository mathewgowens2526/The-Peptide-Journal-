# The Peptide Journal — Etsy buyer-code edition

This edition adds one-time buyer activation codes, a seller code desk, server-side code verification, and code revocation. Journal content continues to stay in each buyer's browser local storage; it is not uploaded to Netlify or the license store.

## Important deployment note

This project uses Netlify Functions and Netlify Blobs. Do **not** publish it with Netlify Drop / a simple drag-and-drop ZIP upload. Connect this folder to a Git repository and let Netlify build it, or deploy it with the Netlify CLI so the functions are bundled.

## Deploy to the existing Netlify site

1. Unzip this package on a computer.
2. Create a **private** GitHub repository and upload the contents of this folder (keep the folder structure). Do not upload `PRIVATE_SETUP_SECRETS.txt`.
3. In Netlify, open the existing site `thepeptidejournal` and connect it to that GitHub repository under **Project configuration → Build & deploy → Continuous deployment**.
4. Confirm the build settings from `netlify.toml`: build command `npm install`, publish directory `public`, functions directory `netlify/functions`.
5. In Netlify **Project configuration → Environment variables**, add these two variables using the values in your separate private setup-secrets file:
   - `ADMIN_SECRET`
   - `LICENSE_SIGNING_SECRET`
   Make sure they are available to Functions. Do not put either secret in HTML, JavaScript, GitHub, or Etsy files.
6. Trigger a fresh production deploy. Netlify Functions can read environment variables at runtime; changes require a new deploy.
7. Test the public root URL. It should show the access-code screen, not the journal. Test an issued code on a separate browser/device.

## Generate codes after a sale

1. Visit `https://thepeptidejournal.netlify.app/admin.html` while signed in as the seller (the page itself is not password protected; the server requires your secret for every action).
2. Paste your `ADMIN_SECRET`, choose 1 code, and generate it.
3. Copy the code immediately and deliver it to the buyer through Etsy's made-to-order digital delivery / message workflow. Do not include your admin secret or setup-secrets file.
4. Keep a private record of which Etsy order received each code. The service stores only a hash of each code, not the readable code.
5. If needed, use the revoke section on the seller page to deactivate a code.

## Buyer experience

- Buyer opens the site and enters the code once.
- The code activates on that browser/device only. The browser receives a secure, HttpOnly license cookie.
- Buyer can then use Add to Home Screen / Install App.
- If they switch phones or erase site data/cookies, contact the shop for a replacement code. Existing journal data can only be moved using the app's JSON backup and restore tools.

## Privacy and limitations

- The license service stores code hashes and activation status only. It does not receive journal entries, photos, symptoms, meals, notes, or backup files.
- Journal records remain in the buyer's local browser storage. They do not sync across devices. Buyers should export backups regularly.
- The app shell is served only after server-side code verification, but this is a deterrent rather than tamper-proof DRM. A technically skilled person may still inspect public static assets or an already cached/offline copy. Revocation cannot erase an offline cached copy.
- A code is single-device/single-browser activation. This package does not automatically process Etsy orders; code delivery is manual as requested.
- Netlify Blobs is used only for license metadata. Netlify's documentation notes that Blobs is key-value storage and that its serving function is the access gate.

## Test checklist before selling

- [ ] Root URL displays access-code gate in a fresh browser.
- [ ] Invalid code is rejected.
- [ ] A valid code unlocks the journal.
- [ ] The same code works again on the same browser/device.
- [ ] The same code is rejected on a second browser/device.
- [ ] A second code works independently.
- [ ] Revoking a code blocks the online app on next load.
- [ ] Test adding a record, exporting a backup, and importing it.
- [ ] Install to Home Screen on iPhone Safari and Android Chrome.
- [ ] Test offline behavior and explain to buyers that an already cached app may remain accessible offline.


## New reference tabs
The customer app now includes two added tabs: **Cheat Sheet** and **Reference Sheet**, plus the existing editable personal reference notes tab. These summarize names and source-described topic/benefit claims from the seller-provided reference images. Claims are explicitly labeled as unverified source wording. Dosing, frequency, timing, vial reconstitution and bacteriostatic-water instructions are not reproduced; customers must rely on their own product labeling and licensed clinician/pharmacist. Some unclear source abbreviations are flagged for confirmation.
