import { getStore } from "@netlify/blobs";
import { createHash, createHmac, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";

const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
});
const store = () => getStore({ name: "peptide-journal-licenses", consistency: "strong" });
const normalize = (code) => String(code || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
const hashCode = (code) => createHash("sha256").update(normalize(code)).digest("hex");
const sign = (payload) => {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = createHmac("sha256", process.env.LICENSE_SIGNING_SECRET).update(body).digest("base64url");
  return `${body}.${sig}`;
};
const makeCode = () => {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(16);
  let raw = "";
  for (const b of bytes) raw += alphabet[b % alphabet.length];
  return `PJ-${raw.slice(0,4)}-${raw.slice(4,8)}-${raw.slice(8,12)}-${raw.slice(12,16)}`;
};
const adminOK = (req) => {
  const expected = process.env.ADMIN_SECRET || "";
  const actual = req.headers.get("x-admin-secret") || "";
  if (!expected || !actual) return false;
  const a = Buffer.from(actual), b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
};

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Use POST." }, 405, { allow: "POST" });
  if (!process.env.ADMIN_SECRET || !process.env.LICENSE_SIGNING_SECRET) return json({ error: "License service is not configured. The site owner must finish setup." }, 503);
  let body;
  try { body = await req.json(); } catch { return json({ error: "Invalid request." }, 400); }
  const action = body.action;
  const db = store();

  if (action === "issue") {
    if (!adminOK(req)) return json({ error: "Admin authorization failed." }, 401);
    const count = Math.max(1, Math.min(20, Number(body.count) || 1));
    const issued = [];
    for (let i = 0; i < count; i++) {
      let code, key, result;
      do {
        code = makeCode(); key = `code:${hashCode(code)}`;
        result = await db.setJSON(key, { status: "issued", createdAt: new Date().toISOString(), licenseId: randomUUID() }, { onlyIfNew: true });
      } while (!result.modified);
      issued.push(code);
    }
    return json({ codes: issued });
  }

  if (action === "revoke") {
    if (!adminOK(req)) return json({ error: "Admin authorization failed." }, 401);
    const code = normalize(body.code);
    if (code.length !== 18) return json({ error: "Enter a complete access code." }, 400);
    const key = `code:${hashCode(code)}`;
    const item = await db.getWithMetadata(key, { consistency: "strong", type: "json" });
    if (!item) return json({ error: "Code not found." }, 404);
    const updated = { ...item.data, status: "revoked", revokedAt: new Date().toISOString() };
    await db.setJSON(key, updated, { onlyIfMatch: item.etag });
    if (item.data.licenseId) {
      const lic = await db.getWithMetadata(`license:${item.data.licenseId}`, { consistency: "strong", type: "json" });
      if (lic) await db.setJSON(`license:${item.data.licenseId}`, { ...lic.data, status: "revoked", revokedAt: new Date().toISOString() }, { onlyIfMatch: lic.etag });
    }
    return json({ ok: true, message: "Code revoked." });
  }

  if (action === "activate") {
    const code = normalize(body.code);
    const deviceId = String(body.deviceId || "");
    if (code.length !== 18 || !/^[a-zA-Z0-9-]{20,80}$/.test(deviceId)) return json({ error: "Enter the full code and try again." }, 400);
    const key = `code:${hashCode(code)}`;
    const item = await db.getWithMetadata(key, { consistency: "strong", type: "json" });
    if (!item || item.data.status === "revoked") return json({ error: "That access code is invalid or has been deactivated." }, 403);
    if (item.data.status === "issued") {
      const updated = { ...item.data, status: "activated", deviceId, activatedAt: new Date().toISOString() };
      const saved = await db.setJSON(key, updated, { onlyIfMatch: item.etag });
      if (!saved.modified) return json({ error: "This code is being activated elsewhere. Please try again." }, 409);
      await db.setJSON(`license:${item.data.licenseId}`, { status: "active", deviceId, activatedAt: updated.activatedAt });
    } else if (item.data.status === "activated" && item.data.deviceId === deviceId) {
      await db.setJSON(`license:${item.data.licenseId}`, { status: "active", deviceId, activatedAt: item.data.activatedAt });
    } else {
      return json({ error: "This code has already been activated on another browser or device. Contact the Etsy shop for help." }, 403);
    }
    const token = sign({ licenseId: item.data.licenseId, deviceId, exp: Math.floor(Date.now()/1000) + 60*60*24*365*5 });
    const cookie = `pj_license=${token}; Path=/; Max-Age=157680000; HttpOnly; Secure; SameSite=Lax`;
    return json({ ok: true }, 200, { "set-cookie": cookie });
  }

  return json({ error: "Unknown action." }, 400);
};
