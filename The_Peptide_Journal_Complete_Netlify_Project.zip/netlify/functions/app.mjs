import { getStore } from "@netlify/blobs";
import { createHmac, timingSafeEqual } from "node:crypto";
import { APP_HTML } from "../app-template.mjs";

const gate = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#718675"><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/icons/icon-192.png"><title>Unlock The Peptide Journal</title><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:22px;background:#f7f6f0;color:#29352e;font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.card{width:min(100%,440px);background:#fffefa;border:1px solid #e3e8e1;border-radius:24px;padding:28px;box-shadow:0 12px 40px #29352e12}.mark{width:48px;height:48px;display:grid;place-items:center;border-radius:16px;background:#718675;color:white;font-size:26px}h1{font:500 29px Georgia,serif;margin:17px 0 6px}p{color:#78847b;font-size:13px}label{display:block;font-size:12px;margin:20px 0 6px;color:#526b5b}input{width:100%;border:1px solid #e3e8e1;border-radius:12px;padding:14px;font-size:16px;letter-spacing:.08em;text-transform:uppercase}button{width:100%;margin-top:12px;border:0;border-radius:12px;padding:14px;background:#718675;color:white;font-weight:700;font-size:14px}button:disabled{opacity:.6}#msg{min-height:24px;font-size:12px;color:#815b4d;margin-top:10px}.fine{font-size:11px;margin-top:18px}.fine a{color:#526b5b}</style></head><body><main class="card"><div class="mark">✿</div><h1>Welcome to The Peptide Journal</h1><p>Enter the unique access code included with your Etsy purchase to unlock your private journal on this device.</p><form id="form"><label for="code">YOUR ACCESS CODE</label><input id="code" autocomplete="one-time-code" placeholder="PJ-XXXX-XXXX-XXXX-XXXX" required maxlength="23"><button id="submit">Unlock my journal</button></form><div id="msg" role="status"></div><p class="fine">Already purchased? Check your Etsy digital download. Need help? Contact the Etsy shop and include your order number. Never send your journal backup or private health records.</p></main><script>
const form=document.getElementById('form'),code=document.getElementById('code'),msg=document.getElementById('msg'),btn=document.getElementById('submit');
let deviceId=localStorage.getItem('pj_device_id');if(!deviceId){deviceId=(crypto.randomUUID?crypto.randomUUID():('pj-'+Date.now()+'-'+Math.random().toString(36).slice(2)));localStorage.setItem('pj_device_id',deviceId)}
form.addEventListener('submit',async e=>{e.preventDefault();btn.disabled=true;btn.textContent='Checking code…';msg.textContent='';try{const r=await fetch('/.netlify/functions/license',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'activate',code:code.value,deviceId})});const d=await r.json();if(!r.ok)throw new Error(d.error||'Could not activate this code.');msg.style.color='#526b5b';msg.textContent='Access confirmed. Opening your journal…';location.reload()}catch(err){msg.style.color='#815b4d';msg.textContent=err.message;btn.disabled=false;btn.textContent='Unlock my journal'}});
</script></body></html>`;

function verify(token) {
  if (!token || !process.env.LICENSE_SIGNING_SECRET) return null;
  const parts = token.split("."); if (parts.length !== 2) return null;
  const [body, sig] = parts;
  const expected = createHmac("sha256", process.env.LICENSE_SIGNING_SECRET).update(body).digest("base64url");
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a,b)) return null;
  try { const payload = JSON.parse(Buffer.from(body,"base64url").toString("utf8")); if (!payload.licenseId || !payload.deviceId || payload.exp < Date.now()/1000) return null; return payload; } catch { return null; }
}

export default async (req) => {
  const cookies = req.headers.get("cookie") || "";
  const match = cookies.match(/(?:^|;\s*)pj_license=([^;]+)/);
  const payload = verify(match ? decodeURIComponent(match[1]) : "");
  if (payload) {
    const db = getStore({ name: "peptide-journal-licenses", consistency: "strong" });
    const license = await db.get(`license:${payload.licenseId}`, { consistency: "strong", type: "json" });
    if (license && license.status === "active" && license.deviceId === payload.deviceId) {
      return new Response(APP_HTML, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" } });
    }
  }
  return new Response(gate, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" } });
};
